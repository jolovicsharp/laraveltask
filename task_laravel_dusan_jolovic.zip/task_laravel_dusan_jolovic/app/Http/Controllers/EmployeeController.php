<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class EmployeeController extends Controller
{
    public function index()
    {
        return Employee::all();
    }

    public function show(Employee $employee)
    {
        return $employee;
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), $this->validationRules());

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $employee = Employee::create($request->all());
        return response()->json($employee, 201);
    }

    public function update(Request $request, Employee $employee)
    {
        $validator = Validator::make($request->all(), $this->validationRules($employee->id));

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $employee->update($request->all());
        return response()->json($employee);
    }

    public function destroy(Employee $employee)
    {
        $employee->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }
    public function employee(Request $request)
{
    try {
        $handle = null;

        // Check for direct CSV content type
        if ($request->header('Content-Type') === 'text/csv') {
            $handle = fopen('php://input', 'r');
            if (!$handle) {
                return response()->json(['message' => 'No file content provided.'], 400);
            }
        } elseif ($request->hasFile('import')) {
            $file = $request->file('import');
            if ($file->getClientOriginalExtension() !== 'csv') {
                return response()->json(['message' => 'Invalid file format. Only CSV files are allowed.'], 400);
            }
            $handle = fopen($file->getRealPath(), 'r');
        } else {
            return response()->json(['message' => 'No file uploaded.'], 400);
        }

        $header = fgetcsv($handle);
        $skippedRows = [];
        $batchSize = 500;
        $batchData = [];
        $rowCount = 1;

        while (($row = fgetcsv($handle)) !== false) {
            $rowCount++;

            if (count($row) < 19 || !is_numeric($row[0])) {
                $skippedRows[] = $rowCount;
                continue;
            }

            $dateOfBirth = $this->convertToDate($row[7]);
            if (!$dateOfBirth) {
                $dateOfBirth = '1970-01-01';
            }

            $timeOfBirth = $this->convertToTime($row[8]);
            $dateOfJoining = \DateTime::createFromFormat('n/j/Y', $row[10])->format('Y-m-d');

            $batchData[] = [
                'employee_id' => is_numeric($row[0]) ? $row[0] : null,
                'name_prefix' => $row[1],
                'first_name' => $row[2],
                'middle_initial' => $row[3],
                'last_name' => $row[4],
                'gender' => $row[5],
                'email' => $row[6],
                'date_of_birth' => $dateOfBirth,
                'time_of_birth' => $timeOfBirth,
                'age_in_yrs' => $row[9],
                'date_of_joining' => $dateOfJoining,
                'age_in_company' => $row[11],
                'phone_no' => $row[12],
                'place_name' => $row[13],
                'county' => $row[14],
                'city' => $row[15],
                'zip' => $row[16],
                'region' => $row[17],
                'user_name' => $row[18]
            ];

            if (count($batchData) === $batchSize) {
                $this->insertOrUpdateBatch($batchData);
                $batchData = [];
            }
        }

        if (!empty($batchData)) {
            $this->insertOrUpdateBatch($batchData);
        }

        fclose($handle);

        if (!empty($skippedRows)) {
            return response()->json([
                'message' => 'Import completed with some rows skipped.',
                'skipped_rows' => $skippedRows
            ], 200);
        }

        return response()->json(['message' => 'Import was successful.'], 200);
    } catch (\Exception $e) {
        return response()->json(['message' => 'An error occurred during import.', 'error' => $e->getMessage()], 500);
    }
}
    
    private function insertOrUpdateBatch($batchData)
{
    if (empty($batchData)) {
        return;
    }
    $baseQuery = "INSERT INTO employees (employee_id, name_prefix, first_name, middle_initial, last_name, gender, email, date_of_birth, time_of_birth, age_in_yrs, date_of_joining, age_in_company, phone_no, place_name, county, city, zip, region, user_name) VALUES ";
    $values = [];
    $placeholders = [];
    foreach ($batchData as $data) {
        $placeholders[] = "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $values = array_merge($values, array_values($data));
    }
    $updateQuery = "ON DUPLICATE KEY UPDATE name_prefix = VALUES(name_prefix), first_name = VALUES(first_name), middle_initial = VALUES(middle_initial), last_name = VALUES(last_name), gender = VALUES(gender), email = VALUES(email), date_of_birth = VALUES(date_of_birth), time_of_birth = VALUES(time_of_birth), age_in_yrs = VALUES(age_in_yrs), date_of_joining = VALUES(date_of_joining), age_in_company = VALUES(age_in_company), phone_no = VALUES(phone_no), place_name = VALUES(place_name), county = VALUES(county), city = VALUES(city), zip = VALUES(zip), region = VALUES(region), user_name = VALUES(user_name)";
    $query = $baseQuery . implode(', ', $placeholders) . ' ' . $updateQuery;
    DB::statement($query, $values);
}


    private function validationRules($id = null)
    {
        return [
            'employee_id' => 'required|unique:employees,employee_id' . ($id ? ',' . $id : ''),
            'user_name' => 'required|unique:employees,user_name' . ($id ? ',' . $id : ''),
            'email' => 'required|email|unique:employees,email' . ($id ? ',' . $id : ''),
            'gender' => 'required|in:Male,Female,Other',
            'date_of_birth' => 'required|date',
            'time_of_birth' => 'required|date_format:H:i:s',
            'age_in_yrs' => 'required|integer',
            'date_of_joining' => 'required|date',
            'age_in_company' => 'required|numeric',
            'phone_no' => 'required',
        ];
    }

    private function convertToDate($rawDate)
{
    $possibleFormats = ['Y-m-d', 'n/j/Y', 'm/d/Y', 'd/m/Y'];

    foreach ($possibleFormats as $format) {
        try {
            $dateOfBirthObject = \DateTime::createFromFormat($format, $rawDate);
            if ($dateOfBirthObject !== false && $dateOfBirthObject->format($format) == $rawDate) { // This check ensures the format matches exactly
                return $dateOfBirthObject->format('Y-m-d');
            }
        } catch (\Exception $e) {
        }
    }

    return '1970-01-01'; // Return default date if no format matches
}


    private function convertToTime($rawTime)
    {
        try {
            $timeOfBirthObject = \DateTime::createFromFormat('h:i:s A', $rawTime);
            if ($timeOfBirthObject === false) {
                return '00:00:00'; // Default time if conversion fails
            }
            return $timeOfBirthObject->format('H:i:s');
        } catch (\Exception $e) {
            return '00:00:00'; // Default time if conversion fails
        }
    }
}
